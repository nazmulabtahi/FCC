@echo off
if not exist .venv py -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Edit .env now. Set a unique ADMIN_PASSWORD and SECRET_KEY.
echo For local use keep APP_ENV=development and COOKIE_SECURE=false.
echo Then run this file again.
pause
set -a 2>nul
for /f "usebackq tokens=1,* delims==" %%A in (".env") do if not "%%A"=="" set "%%A=%%B"
uvicorn main:app --host 127.0.0.1 --port 8000
