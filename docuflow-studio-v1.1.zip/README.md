# DocuFlow Studio

A self-hosted PDF/GIF processing starter with a responsive web interface.

## Features
- Merge multiple PDFs into one PDF
- Arrange PDF pages 2, 4, 6, 8 or 9 per sheet (N-up)
- Invert PDF page colors
- Join multiple animated GIFs into one animation
- Admin login and recent processing-job dashboard
- Upload streaming with a configurable server-side limit (default 500 MB)

## Run on Windows
1. Install Python 3.11 or newer.
2. Extract this ZIP.
3. Double-click `run_windows.bat` once to install dependencies.
4. Edit `.env`: set a strong `ADMIN_PASSWORD` and random `SECRET_KEY`.
5. Run `run_windows.bat` again and open http://127.0.0.1:8000.

## Run on macOS/Linux
```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
cp .env.example .env  # if not created
# Edit .env, then:
source .venv/bin/activate
set -a && source .env && set +a
uvicorn main:app --host 127.0.0.1 --port 8000
```

## Important production notes
- This starter is designed to run on a server you control. Do not expose it publicly until you set strong secrets, enable HTTPS, configure `COOKIE_SECURE=true`, and put it behind a production reverse proxy.
- Set the reverse proxy request-body limit to at least your chosen `MAX_UPLOAD_MB` (for example, nginx `client_max_body_size 550m;`).
- Use persistent disk for `WORK_DIR`; periodically delete old generated files from that folder. The sample keeps outputs there so downloads survive request cleanup.
- The Admin dashboard lists recent jobs in memory; restarting the app clears this list. For a multi-user public service, add a database, per-user accounts, quotas, background task queue, and automatic output cleanup.
- PDF color inversion rasterizes pages, so text may no longer be selectable and output size can grow. Increase/decrease DPI in the API if needed.
- N-up currently processes uploaded PDFs in their upload order and pages in original order. The 6-up layout is 3 columns × 2 rows; 8-up is 4 × 2.
- GIFs are concatenated in upload order. Frames are centered on a transparent canvas sized to the largest frame.

## Limits
The configured upload limit is per file. For multiple files, the total request size also needs to be allowed by your hosting proxy/server. Large jobs need adequate RAM, CPU and disk space.
