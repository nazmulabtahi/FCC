import os, uuid, shutil, tempfile, time, sqlite3
from pathlib import Path
from typing import List
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request, Response
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")
import fitz
from pypdf import PdfReader, PdfWriter
from PIL import Image, ImageSequence

APP_DIR = Path(__file__).parent
WORK_DIR = Path(os.getenv("WORK_DIR", APP_DIR / "work"))
WORK_DIR.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-this-password")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key-before-deploying")
if os.getenv("APP_ENV", "development").lower() == "production":
    if ADMIN_PASSWORD == "change-this-password" or SECRET_KEY == "change-this-secret-key-before-deploying":
        raise RuntimeError("Set ADMIN_PASSWORD and SECRET_KEY before production deployment.")
COOKIE_NAME = "docuflow_admin"
serializer = URLSafeTimedSerializer(SECRET_KEY, salt="docuflow-admin")
DB_PATH = Path(os.getenv("DB_PATH", APP_DIR / "docuflow.db"))

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, type TEXT NOT NULL, status TEXT NOT NULL,
            file TEXT NOT NULL, time TEXT NOT NULL
        )""")

init_db()

app = FastAPI(title="DocuFlow Studio", version="1.1.0")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")

def is_admin(request: Request):
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return False
    try:
        data = serializer.loads(token, max_age=60 * 60 * 12)
        return data.get("username") == ADMIN_USERNAME
    except (BadSignature, SignatureExpired):
        return False

def record_job(kind, status, filename):
    with db() as conn:
        conn.execute(
            "INSERT INTO jobs (id, type, status, file, time) VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4())[:8], kind, status, filename[:500],
             time.strftime("%Y-%m-%d %H:%M:%S"))
        )
        conn.execute("""DELETE FROM jobs WHERE id NOT IN
                        (SELECT id FROM jobs ORDER BY time DESC LIMIT 200)""")

async def save_upload(upload: UploadFile, folder: Path):
    name = Path(upload.filename or "upload").name
    suffix = Path(name).suffix.lower()
    path = folder / f"{uuid.uuid4().hex}{suffix}"
    total = 0
    with path.open("wb") as out:
        while chunk := await upload.read(1024 * 1024):
            total += len(chunk)
            if total > MAX_UPLOAD_MB * 1024 * 1024:
                path.unlink(missing_ok=True)
                raise HTTPException(413, f"File exceeds the {MAX_UPLOAD_MB} MB upload limit.")
            out.write(chunk)
    return path, name

def output_response(path: Path, download_name: str, media_type: str):
    return FileResponse(path, media_type=media_type, filename=download_name,
                        background=None)

@app.get("/", response_class=HTMLResponse)
def home():
    return (APP_DIR / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "max_upload_mb": MAX_UPLOAD_MB}

@app.post("/api/pdf/merge")
async def pdf_merge(files: List[UploadFile] = File(...)):
    if len(files) < 2:
        raise HTTPException(400, "Upload at least two PDF files.")
    with tempfile.TemporaryDirectory(dir=WORK_DIR) as td:
        folder = Path(td)
        writer = PdfWriter()
        names = []
        try:
            for f in files:
                path, name = await save_upload(f, folder)
                if path.suffix != ".pdf":
                    raise HTTPException(400, f"{name} is not a PDF.")
                reader = PdfReader(str(path), strict=False)
                if reader.is_encrypted:
                    raise HTTPException(400, f"{name} is password-protected.")
                for page in reader.pages:
                    writer.add_page(page)
                names.append(name)
            out = folder / "merged.pdf"
            with out.open("wb") as stream:
                writer.write(stream)
            record_job("PDF Merge", "Completed", ", ".join(names[:3]))
            # FileResponse must outlive TemporaryDirectory; copy to persistent short-lived output.
            final = WORK_DIR / f"{uuid.uuid4().hex}.pdf"
            shutil.copy2(out, final)
            return FileResponse(final, media_type="application/pdf", filename="merged.pdf",
                                background=None)
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(400, f"Could not merge PDFs: {str(e)[:180]}")

@app.post("/api/pdf/nup")
async def pdf_nup(files: List[UploadFile] = File(...), per_sheet: int = Form(6),
                  orientation: str = Form("landscape")):
    if per_sheet not in (2, 4, 6, 8, 9):
        raise HTTPException(400, "Choose 2, 4, 6, 8 or 9 pages per sheet.")
    if not files:
        raise HTTPException(400, "Upload at least one PDF.")
    with tempfile.TemporaryDirectory(dir=WORK_DIR) as td:
        folder = Path(td)
        writer = PdfWriter()
        try:
            for f in files:
                path, name = await save_upload(f, folder)
                if path.suffix != ".pdf":
                    raise HTTPException(400, f"{name} is not a PDF.")
                doc = fitz.open(path)
                if doc.is_encrypted:
                    raise HTTPException(400, f"{name} is password-protected.")
                cols = 2 if per_sheet in (2, 4, 6, 8, 9) else 2
                rows = (per_sheet + cols - 1) // cols
                if per_sheet == 2: cols, rows = 2, 1
                elif per_sheet == 4: cols, rows = 2, 2
                elif per_sheet == 6: cols, rows = 3, 2
                elif per_sheet == 8: cols, rows = 4, 2
                elif per_sheet == 9: cols, rows = 3, 3
                page_w, page_h = (842, 595) if orientation == "landscape" else (595, 842)
                cell_w, cell_h = page_w / cols, page_h / rows
                for start in range(0, len(doc), per_sheet):
                    out_doc = fitz.open()
                    sheet = out_doc.new_page(width=page_w, height=page_h)
                    for idx in range(per_sheet):
                        page_no = start + idx
                        if page_no >= len(doc): break
                        r, c = divmod(idx, cols)
                        rect = fitz.Rect(c * cell_w + 8, r * cell_h + 8,
                                         (c + 1) * cell_w - 8, (r + 1) * cell_h - 8)
                        sheet.show_pdf_page(rect, doc, page_no, keep_proportion=True)
                    out_path = folder / f"sheet-{uuid.uuid4().hex}.pdf"
                    out_doc.save(out_path)
                    out_doc.close()
                    reader = PdfReader(str(out_path), strict=False)
                    for p in reader.pages: writer.add_page(p)
                doc.close()
            out = folder / "nup.pdf"
            with out.open("wb") as stream: writer.write(stream)
            record_job(f"PDF {per_sheet}-up", "Completed", "PDF upload")
            final = WORK_DIR / f"{uuid.uuid4().hex}.pdf"
            shutil.copy2(out, final)
            return FileResponse(final, media_type="application/pdf", filename=f"{per_sheet}-up.pdf")
        except HTTPException: raise
        except Exception as e: raise HTTPException(400, f"Could not create N-up PDF: {str(e)[:180]}")

@app.post("/api/pdf/invert")
async def pdf_invert(files: List[UploadFile] = File(...), dpi: int = Form(120)):
    if len(files) != 1:
        raise HTTPException(400, "Upload one PDF for color inversion.")
    with tempfile.TemporaryDirectory(dir=WORK_DIR) as td:
        folder = Path(td)
        path, name = await save_upload(files[0], folder)
        if path.suffix != ".pdf": raise HTTPException(400, "The uploaded file is not a PDF.")
        try:
            src = fitz.open(path)
            out_doc = fitz.open()
            for page in src:
                pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72), alpha=False)
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                inverted = Image.eval(img, lambda x: 255 - x)
                img_path = folder / f"{uuid.uuid4().hex}.png"
                inverted.save(img_path, format="PNG", optimize=True)
                p = out_doc.new_page(width=page.rect.width, height=page.rect.height)
                p.insert_image(p.rect, filename=str(img_path))
            out = folder / "inverted.pdf"
            out_doc.save(out, garbage=4, deflate=True)
            src.close(); out_doc.close()
            record_job("PDF Color Invert", "Completed", name)
            final = WORK_DIR / f"{uuid.uuid4().hex}.pdf"
            shutil.copy2(out, final)
            return FileResponse(final, media_type="application/pdf", filename="inverted.pdf")
        except Exception as e: raise HTTPException(400, f"Could not invert PDF: {str(e)[:180]}")

@app.post("/api/gif/merge")
async def gif_merge(files: List[UploadFile] = File(...)):
    if len(files) < 2: raise HTTPException(400, "Upload at least two GIF files.")
    with tempfile.TemporaryDirectory(dir=WORK_DIR) as td:
        folder = Path(td)
        frames, durations = [], []
        try:
            for f in files:
                path, name = await save_upload(f, folder)
                if path.suffix != ".gif": raise HTTPException(400, f"{name} is not a GIF.")
                im = Image.open(path)
                for frame in ImageSequence.Iterator(im):
                    fr = frame.convert("RGBA")
                    frames.append(fr.copy())
                    durations.append(frame.info.get("duration", im.info.get("duration", 100)))
                im.close()
            if not frames: raise HTTPException(400, "No GIF frames found.")
            # Normalize frame dimensions to the largest uploaded frame, preserving aspect ratio.
            width = max(x.width for x in frames); height = max(x.height for x in frames)
            normalized = []
            for frame in frames:
                canvas = Image.new("RGBA", (width, height), (255,255,255,0))
                frame.thumbnail((width, height), Image.Resampling.LANCZOS)
                canvas.alpha_composite(frame, ((width-frame.width)//2, (height-frame.height)//2))
                normalized.append(canvas.convert("P", palette=Image.Palette.ADAPTIVE))
            out = folder / "merged.gif"
            normalized[0].save(out, save_all=True, append_images=normalized[1:],
                               duration=durations, loop=0, optimize=False, disposal=2)
            record_job("GIF Merge", "Completed", f"{len(files)} GIF files")
            final = WORK_DIR / f"{uuid.uuid4().hex}.gif"
            shutil.copy2(out, final)
            return FileResponse(final, media_type="image/gif", filename="merged.gif")
        except HTTPException: raise
        except Exception as e: raise HTTPException(400, f"Could not merge GIFs: {str(e)[:180]}")

@app.post("/api/admin/login")
async def admin_login(request: Request, response: Response):
    data = await request.json()
    if data.get("username") != ADMIN_USERNAME or data.get("password") != ADMIN_PASSWORD:
        raise HTTPException(401, "Incorrect admin username or password.")
    token = serializer.dumps({"username": ADMIN_USERNAME})
    response.set_cookie(COOKIE_NAME, token, httponly=True, samesite="strict",
                        secure=os.getenv("COOKIE_SECURE", "false").lower() == "true",
                        max_age=60*60*12)
    return {"ok": True}

@app.post("/api/admin/logout")
def admin_logout(response: Response):
    response.delete_cookie(COOKIE_NAME)
    return {"ok": True}

@app.get("/api/admin/jobs")
def admin_jobs(request: Request):
    if not is_admin(request): raise HTTPException(401, "Admin login required.")
    with db() as conn:
        rows = conn.execute(
            "SELECT id, type, status, file, time FROM jobs ORDER BY rowid DESC LIMIT 100"
        ).fetchall()
    return {"jobs": [dict(row) for row in rows], "max_upload_mb": MAX_UPLOAD_MB}
