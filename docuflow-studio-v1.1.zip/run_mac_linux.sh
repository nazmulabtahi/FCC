#!/usr/bin/env bash
set -e
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "Edit .env with a unique ADMIN_PASSWORD and SECRET_KEY."
set -a
source .env
set +a
uvicorn main:app --host 127.0.0.1 --port 8000
